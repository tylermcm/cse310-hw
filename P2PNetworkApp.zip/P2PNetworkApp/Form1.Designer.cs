﻿namespace P2PNetworkApp
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.receiveBox = new System.Windows.Forms.TextBox();
            this.sendBox = new System.Windows.Forms.TextBox();
            this.ipBox = new System.Windows.Forms.TextBox();
            this.connectButton = new System.Windows.Forms.Button();
            this.nameLabel = new System.Windows.Forms.Label();
            this.sendButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // receiveBox
            // 
            this.receiveBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F);
            this.receiveBox.Location = new System.Drawing.Point(22, 143);
            this.receiveBox.Margin = new System.Windows.Forms.Padding(3, 20, 3, 20);
            this.receiveBox.MaxLength = 5000000;
            this.receiveBox.Multiline = true;
            this.receiveBox.Name = "receiveBox";
            this.receiveBox.ReadOnly = true;
            this.receiveBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.receiveBox.Size = new System.Drawing.Size(623, 425);
            this.receiveBox.TabIndex = 10;
            this.receiveBox.TabStop = false;
            // 
            // sendBox
            // 
            this.sendBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F);
            this.sendBox.Location = new System.Drawing.Point(22, 591);
            this.sendBox.Margin = new System.Windows.Forms.Padding(3, 3, 3, 20);
            this.sendBox.MaxLength = 5000000;
            this.sendBox.Multiline = true;
            this.sendBox.Name = "sendBox";
            this.sendBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.sendBox.Size = new System.Drawing.Size(543, 40);
            this.sendBox.TabIndex = 3;
            // 
            // ipBox
            // 
            this.ipBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.ipBox.Location = new System.Drawing.Point(23, 80);
            this.ipBox.Margin = new System.Windows.Forms.Padding(3, 20, 20, 3);
            this.ipBox.MaxLength = 45;
            this.ipBox.Multiline = true;
            this.ipBox.Name = "ipBox";
            this.ipBox.Size = new System.Drawing.Size(300, 40);
            this.ipBox.TabIndex = 1;
            this.ipBox.Text = "Enter ip address";
            // 
            // connectButton
            // 
            this.connectButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.connectButton.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.connectButton.Font = new System.Drawing.Font("Trebuchet MS", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.connectButton.Location = new System.Drawing.Point(346, 80);
            this.connectButton.Name = "connectButton";
            this.connectButton.Size = new System.Drawing.Size(300, 40);
            this.connectButton.TabIndex = 2;
            this.connectButton.Text = "Connect!";
            this.connectButton.UseVisualStyleBackColor = true;
            // 
            // nameLabel
            // 
            this.nameLabel.AutoSize = true;
            this.nameLabel.Location = new System.Drawing.Point(23, 20);
            this.nameLabel.MaximumSize = new System.Drawing.Size(623, 40);
            this.nameLabel.MinimumSize = new System.Drawing.Size(623, 40);
            this.nameLabel.Name = "nameLabel";
            this.nameLabel.Size = new System.Drawing.Size(623, 40);
            this.nameLabel.TabIndex = 11;
            this.nameLabel.Text = "label1";
            // 
            // sendButton
            // 
            this.sendButton.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.sendButton.Font = new System.Drawing.Font("Trebuchet MS", 15F);
            this.sendButton.Location = new System.Drawing.Point(571, 591);
            this.sendButton.Name = "sendButton";
            this.sendButton.Size = new System.Drawing.Size(74, 40);
            this.sendButton.TabIndex = 12;
            this.sendButton.Text = "Send";
            this.sendButton.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(669, 648);
            this.Controls.Add(this.sendButton);
            this.Controls.Add(this.nameLabel);
            this.Controls.Add(this.connectButton);
            this.Controls.Add(this.ipBox);
            this.Controls.Add(this.sendBox);
            this.Controls.Add(this.receiveBox);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Name = "Form1";
            this.Padding = new System.Windows.Forms.Padding(20);
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.Button sendButton;

        #endregion

        private System.Windows.Forms.TextBox receiveBox;
        private System.Windows.Forms.TextBox sendBox;
        private System.Windows.Forms.TextBox ipBox;
        private System.Windows.Forms.Button connectButton;
        private System.Windows.Forms.Label nameLabel;
    }
}

