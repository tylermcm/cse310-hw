﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace P2PNetworkApp
{
    public partial class Form1 : Form
    {
        private TcpListener _server;
        private IPAddress _ipAddress;

        public Form1()
        {
            InitializeComponent();
            connectButton.Click += connectButton_Click;
            sendButton.Click += sendButton_Click;
        }

        private void connectButton_Click(object sender, EventArgs e)
        {
            try
            {
                Int32 port = 13000;
                _ipAddress = IPAddress.Parse(ipBox.Text);
                _server = new TcpListener(_ipAddress, port);

                _server.Start();
                receiveBox.AppendText("Waiting for a connection... \n");
                Task.Run(() => AcceptClientsAsync());
            }
            catch (SocketException se)
            {
                receiveBox.AppendText($"SocketException: {se}\n");
            }
        }

        private async Task AcceptClientsAsync()
        {
            while (true)
            {
                TcpClient client = await _server.AcceptTcpClientAsync();
                receiveBox.AppendText("Connected!\n");
                Task.Run(() => HandleClientAsync(client));
            }
        }

        private async Task HandleClientAsync(TcpClient client)
        {
            Byte[] bytes = new Byte[256];
            String data = null;
            NetworkStream stream = client.GetStream();

            int i;
            while ((i = await stream.ReadAsync(bytes, 0, bytes.Length)) != 0)
            {
                data = Encoding.ASCII.GetString(bytes, 0, i);
                this.Invoke(new Action(() =>
                {
                    receiveBox.AppendText(String.Format(">> {0}\n", data));
                }));

                data = data.ToUpper();
                byte[] msg = Encoding.ASCII.GetBytes(data);

                await stream.WriteAsync(msg, 0, msg.Length);
                this.Invoke(new Action(() =>
                {
                    receiveBox.AppendText(String.Format(">> {0}\n", data));
                }));
            }
        }

        private void sendButton_Click(object sender, EventArgs e)
        {
            if(_server != null)
            {
                TcpClient client = new TcpClient();
                client.Connect(_ipAddress, 13000);
                NetworkStream stream = client.GetStream();
                byte[] msg = Encoding.ASCII.GetBytes(sendBox.Text);
                stream.Write(msg, 0, msg.Length);
            }
        }
    }
}
