#ifndef ALLPROGRAMS_H
#define ALLPROGRAMS_H

class AllPrograms
{
public:
	static void clearConsole();
};

#endif
